package com.schoolofnet.FahrenheitClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FahrenheitClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(FahrenheitClientApplication.class, args);
	}

}
