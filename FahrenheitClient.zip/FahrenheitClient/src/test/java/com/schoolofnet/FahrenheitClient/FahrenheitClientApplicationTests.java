package com.schoolofnet.FahrenheitClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FahrenheitClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
