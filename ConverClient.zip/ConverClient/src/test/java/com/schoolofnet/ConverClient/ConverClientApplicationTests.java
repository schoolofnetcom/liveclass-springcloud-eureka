package com.schoolofnet.ConverClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConverClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
