package com.schoolofnet.KelvinClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KelvinClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
