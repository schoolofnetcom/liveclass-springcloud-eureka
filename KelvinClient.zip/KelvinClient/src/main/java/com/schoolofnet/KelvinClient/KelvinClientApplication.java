package com.schoolofnet.KelvinClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KelvinClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(KelvinClientApplication.class, args);
	}

}
